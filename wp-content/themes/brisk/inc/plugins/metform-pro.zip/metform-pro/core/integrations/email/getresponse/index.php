<?php
// At the day of judgment we shall all meet again.